<?php include("connection.php");
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <div class="container">
    <ul class="nav">

      <?php 
      
            if($_SESSION["role"]=="Owner"){

      ?>
        <li class="nav-iterm">
            <a class="nav-link" href="index.php">
                <i class="fa fa-home fa-lg"></i>
            </a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" data-toggle="modal" data-target="#myModalAboutUs" href="#">About Us</a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" data-toggle="modal" data-target="#myModal" href="#">Contact Us</a>
        </li>
        
        
        <?php 
        
            }else if ($_SESSION["role"]=="Admin")
            
            { ?>


<li class="nav-iterm">
            <a class="nav-link" href="add_user.php">Add User</a>
        </li>
       <li class="nav-iterm">
            <a class="nav-link" href="view_user.php">View user</a>
        </li>

          
          <?php
            }
        ?>
      
      
        <li class="nav-iterm">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
        
    </ul>

</div>
</head>
<body>
        <!-- Modal  -->
    <div class="container">  
 
  <!-- Contact Us Modal -->  
  <div class="modal fade" id="myModal" role="dialog">  
    <div class="modal-dialog">  
      
      <!-- Modal content-->  
      <div class="modal-content" style="background-color: #054D44">  
        <div class="modal-header">   
          <p class="modal-title">Contact Us</p>  
          
        </div>  
        <div class="modal-body">  

          <p>Welcome to the Parking Space Management System</p> 
          <p>P.O Box 2020</p> 
          <p>Zanzibar/Tanzania</p>
          <p>Email: parkingmgt@gmail.com</p>
            <p>+255 779 108 367/ +255 622 444 054</p>
        </div>  
        <div class="modal-footer">  

          <button type="button" class="btn btn-success" data-dismiss="modal" style="color:white">Close</button>  
        </div>  
      </div>  
        
    </div>  
  </div>  
    
</div>  




<!--Abou Us Modal-->
<!-- Modal  -->
    <div class="container">  
 
  <!-- Modal -->  
  <div class="modal fade" id="myModalAboutUs" role="dialog">  
    <div class="modal-dialog">  
      
      <!-- Modal content-->  
      <div class="modal-content" style="background-color: #054D44">  
        <div class="modal-header">   
          <p class="modal-title">About Us</p>  
          
        </div>  
        <div class="modal-body">  

        <p>Welcome to the Parking Space Management System</p> 
            <p>New technologies for parking because the car is the essential
            parts of our morden life and every year the number of vehicle used
            in a city grows and need for morden parking space increases as a well.
        </p> 
         <p>Zanzibar/Tanzania</p>
        </div>  
        <div class="modal-footer">  

          <button type="button" class="btn btn-success" data-dismiss="modal" style="color:white">Close</button>  
        </div>  
      </div>  
        
    </div>  
  </div>  
    
</div>  

</body>
</html>