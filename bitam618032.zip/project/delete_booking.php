<?php 
    include("connection.php");

    $sql = "DELETE FROM booking WHERE Booking_ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(':id'=>$_GET['id']));
   header("Location:view_booking.php");
?>