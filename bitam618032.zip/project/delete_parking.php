<?php 
    include("connection.php");

    $sql = "DELETE FROM parking WHERE Parking_ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(':id'=>$_GET['id']));
   header("Location:view_parking.php");
?>