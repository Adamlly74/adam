<?php include("connection.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add User</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
</head>
<body>
    <h1 style="font-family:times new roman">Add new Parking</h1>
    <?php include("navs.php"); ?>
    <form action="save_parking.php" method="POST" name="addUser_Form" style="margin-left:10%">
        
        <div class="form-group row"> 
            <label for="inputName" class="col-sm-2 col-form-label">Parking Name:</label>
            <input type="text" class="form-control col-sm-3" name="pname" id="inputName" placeholder="Enter your Parking Name" required>
        </div> 

        <div class="form-group row"> 
            <label for="inputUname" class="col-sm-2 col-form-label">Parking type:</label>
            <input type="text" class="form-control col-sm-3" name="ptype" id="inputUserName" placeholder="Enter your Parking type" required> 
        </div> 

        <div class="form-group row"> 
            <label for="inputEmail" class="col-sm-2 col-form-label">Description</label>
            <input type="text" class="form-control col-sm-3" name="pdesc" id="inputdesc" placeholder="Enter your Description" required> 
        </div> 

        <button type="submit" name="submit" class="btn btn-primary">Submit</button> 

</form>
    
</body>
<?php include("footer.php"); ?>
</html>