<?php
    include("connection.php");


    if(isset($_POST['submit'])
        && isset($_POST['stime']) 
        && isset($_POST['etime']) 
        && isset($_POST['duration'])){

            $sql="INSERT INTO Booking(Starting_time,Ending_time,Duration) 
            VALUES(:stime,:etime,:duration)";
            $stmt=$con->prepare($sql);
            $stmt->execute(array(
                ':stime'=>$_POST['stime'],
                ':etime'=>$_POST['etime'],
                ':duration'=>$_POST['duration']));
            header("location:booking.php");
    }
?>