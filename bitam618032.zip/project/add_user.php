<?php include("connection.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add User</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
</head>
<body>
    <h1 style="font-family:times new roman">Add new User</h1>
    <?php include("navs.php"); ?>
    <form action="save_user.php" method="POST" name="addUser_Form" style="margin-left:10%">
        
        <div class="form-group row" > 
            <label for="inputName" class="col-sm-2 col-form-label">Full Name:</label>
            <input type="text" class="form-control col-sm-3" name="name" id="name" placeholder="Enter your Full Name" required>
           
            <label for="inputName" class="col-sm-2 col-form-label" id="phone1">Phone Number:</label>
            <input type="text" class="form-control col-sm-3" name="phone" id="phone" placeholder="Enter your Phone No">  
            
        </div> 

        <div class="form-group row"> 
            <label for="inputUname" class="col-sm-2 col-form-label">User Name:</label>
            <input type="text" class="form-control col-sm-3" name="uname" id="inputUserName" placeholder="Enter your UserName" required> 
                     
            <label for="inputName" id="address1" class="col-sm-2 col-form-label">Address:</label>
            <input type="text" class="form-control col-sm-3" name="adress" id="address" placeholder="Enter your Adress"> 
          
        </div> 

        <div class="form-group row"> 
            <label for="inputPassword" class="col-sm-2 col-form-label">Password:</label>
            <input type="Password" class="form-control col-sm-3" name="pass" id="inputPassword" placeholder="Eneter your Password" required> 
        </div> 

        <div class="form-group row"> 
            <label for="inputEmail" class="col-sm-2 col-form-label">Email:</label>
            <input type="email" class="form-control col-sm-3" name="email" id="inputEmail" placeholder="Enter your Email" required> 
        </div> 
 
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Role:</label>
            <select onchange="checkRole()" name="role" id="selectRole" class="form-control col-sm-3">
                <option>Select your Role</option>
                <option value="Admin">Admin</option>
                <option value="Owner">Owner</option>
            </select>
        </div> 

        <button type="submit" name="submit" class="btn btn-primary">Submit</button> 

</form>
<script>
function checkRole(){
    var role=document.getElementById('selectRole');
    var phone=document.getElementById('phone1');
    var phone1=document.getElementById('phone');
    var address=document.getElementById('address');
    var address1=document.getElementById('address1');
    
    if(role.value='admin'){
        phone.hidden=true;
        phone1.hidden=true;
        address=hidden=true;
        address1=hidden=true
    }else{
        phone.hidden=false;
        phone1.hidden=false;
        address=hidden=false;
        address1=hidden=false 
    }
}
   
    
</script>
</body>
<?php include("footer.php"); ?>
</html>