<!DOCTYPE html>
<html lang="en">
<head>
        <?php include("navs.php") ?>
</head>
<body>
    <div class="container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Parking Name</th>
                    <th>Parking Type</th>
                    <th>Description</th>
                    <th>Booking ID</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
    <?php
            include_once("connection.php");
            $sql = "SELECT * FROM parking";
            $stmt=$con->query($sql);

            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $id=$row['Parking_ID'];
                $name=$row['Parking_Name'];
                $uname=$row['Parking_Type'];
                $pass=$row['Parking_Desc'];
                $mail=$row['Booking_ID'];
    ?>
            </thead>

            <tbody>
                <tr> 
                    <td> <?php echo $row['Parking_ID']; ?> </td>
                    <td> <?php echo $row['Parking_Name']; ?> </td>
                    <td> <?php echo $row['Parking_Type']; ?> </td>
                    <td> <?php echo $row['Parking_Desc']; ?> </td>
                    <td> <?php echo $row['Booking_ID']; ?> </td>
                    <td>
                    <a href="edit_parking.php?id=<?php echo $id;?>">
                            Edit
                        </a>

                    </td>
                    <td>

                        <a href="delete_parking.php?id=<?php echo $id;?>">
                            Delete
                        </a>
                    </td>
                </tr>
            </tbody>

    <?php 
            }
    ?>
        </table>
    </div>
    </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>