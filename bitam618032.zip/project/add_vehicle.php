<?php include("connection.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add User</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">

    <!-- Validation -->
    <script> function validateForm(){ 
        var name = document.forms["addUser_Form"]["inputid"].value;  
            var add = document.forms["addUser_Form"]["Vehicle"].value;  
                if (name.length < 1){  	
                    document.getElementById('span').innerHTML = "Please enter your name!" 
        return false 
        }else if (Vihecle.length < 1){ 
                      document.getElementById('spcont').innerHTML = "please fill address!" 
             return false 
        } 
    } 
    </script> 
    <style> 
        #span{ 
             color:red; 
        } 
        #nyota{ 
             color:red; 
        } 
        </style>
</head>
<body>
    <h1 style="font-family:times new roman">Add new Vehicle</h1>
    <?php include("navs.php"); ?>
    <form action="save_vehicle.php" id="validation" method="POST" name="addUser_Form" style="margin-left:10%"
    onsubmit="return validateForm()">
        
        <div class="form-group row"> 
            <label for="inputName" class="col-sm-4 col-form-label">Vehicle Name</label>
            <input type="text" class="form-control col-sm-4" name="v_name" id="inputid" placeholder="Enter your Vehicle Name">
            <span id="span"></span>

        </div> 
 
        <div class="form-group row">
            <label for="inputVehicle type" class="col-sm-4 col-form-label">Vehicle type:</label>
            <select name="v_type" id="Vihecle" class="form-control col-sm-4">
            
                <option>Select your Vehicle</option>
                <option value="Toyota">Toyota</option>
                <option value="Suzuki">Suzuki</option>
                <option value="Rava J">Rava J</option>
                <option value="Ist">Ist</option>
                <option value="Noah">Noah</option>
                <span id="spcont"></span>
            </select>
        </div> 

        <button type="submit" name="submit" class="btn btn-primary">Submit</button> 

</form>
    
</body>
<?php include("footer.php"); ?>
</html>