<?php 
    include("connection.php");

    $sql = "DELETE FROM user_details WHERE ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(':id'=>$_GET['id']));
   header("Location:view_user.php");
?>