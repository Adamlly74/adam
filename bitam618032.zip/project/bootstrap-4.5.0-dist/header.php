<?php
    <div class="container">
    <span class="span">ONLINE PARKING WEBSITE</span>
    <ul class="nav">
        <li class="nav-iterm">
            <a class="nav-link" href="#Home.html">
                <i class="fa fa-home fa-lg"></i>
            </a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" href="#Home.html">About US</a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" href="#Home.html">Contact Us</a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" href="#Home.html">Services</a>
        </li>
        <li class="nav-iterm">
            <a class="nav-link" href="#login">Login</a>
        </li>
    </ul>

</div>
?>