<?php
    include("connection.php");

if(isset($_POST['submit'])){

    $sql="UPDATE booking SET Starting_time=:name,Ending_time=:uname,Duration=:pass,
     WHERE Booking_ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(
        ':name'=>$_POST['name'],
        ':uname'=>$_POST['uname'],
        ':pass'=>$_POST['pass'],
        ':id'=>$_POST['id']));
    header("location:view_booking.php");
}else{
    echo "noo";
}
    
?>