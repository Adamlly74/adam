<?php include("connection.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add User</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
</head>
<body>
    <form action="update_user.php" method="POST" name="addUser_Form">
        <?php 
            $id = $_GET["id"];
            $sql = "SELECT * FROM user_details WHERE ID=$id";
            $stmt=$con->query($sql);

            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $id=$row['ID'];
                $name=$row['FullName'];
                $uname=$row['UserName'];
                $pass=$row['Password'];
                $mail=$row['Email'];
                $role=$row['Role'];  
        
        ?>
        <div class="form-group row"> 
            <label for="inputName" class="col-sm-2 col-form-label">Full Name:</label>
            <input type="text" class="form-control col-sm-4" value="<?php echo $name ?>" name="name" id="inputName"> 
        </div> 

        <div class="form-group row"> 
            <label for="inputUname" class="col-sm-2 col-form-label">User Name:</label>
            <input type="text" class="form-control col-sm-4" value="<?php echo $uname ?>" name="uname" id="inputUserName"> 
        </div> 

        <div class="form-group row"> 
            <label for="inputPassword" class="col-sm-2 col-form-label">Password:</label>
            <input type="Password" class="form-control col-sm-4" value="<?php echo $pass ?>" name="pass" id="inputPassword" readonly> 
        </div> 

        <div class="form-group row"> 
            <label for="inputEmail" class="col-sm-2 col-form-label">Email:</label>
            <input type="email" class="form-control col-sm-4" value="<?php echo $mail ?>" name="email" id="inputEmail"> 
        </div> 
        <input type="hidden" value="<?php echo $_GET['id']; ?>" name="id" />
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Role:</label>
            <input type="text" class="form-control col-sm-4" name="role" value="<?php echo $role ?>"> 
        </div> 
<?php      
        }       
    ?>
        <button type="submit" name="submit" class="btn btn-primary">Update</button> 

</form>  
</body>
</html>