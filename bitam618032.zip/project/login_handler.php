<?php
session_start();

    include("connection.php");
    

    if(isset($_POST['btn_login']))
      {

            $sql = "SELECT * FROM user_details WHERE UserName = :username AND
            Password = :pass";
            $stmt = $con->prepare($sql);
            $stmt->execute(array(':username'=>$_POST['username'], 
            ':pass'=>$_POST['pass']));
            $fetch = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $numrows = $stmt->rowCount();
            if($numrows > 0){
                $_SESSION["role"] = $fetch["Role"];
                if($_SESSION["role"]=="Owner"){
                    header("location:home.php");
                }
                else if($_SESSION["role"]=="Admin")
                header("location:home.php");
            }
            else{
                header("location:index.php?wrong username or password");
            }
        }

?>