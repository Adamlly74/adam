<!DOCTYPE html>
<html lang="en">
<head>
        <?php include("navs.php") ?>
</head>
<body>
    <div class="container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
    <?php
            include_once("connection.php");
            $sql = "SELECT * FROM user_details";
            $stmt=$con->query($sql);

            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $id=$row['ID'];
                $name=$row['FullName'];
                $uname=$row['UserName'];
                $pass=$row['Password'];
                $mail=$row['Email'];
                $role=$row['Role'];  
    ?>
            </thead>

            <tbody>
                <tr> 
                    <td> <?php echo $row['ID']; ?> </td>
                    <td> <?php echo $row['FullName']; ?> </td>
                    <td> <?php echo $row['UserName']; ?> </td>
                    <td> <?php echo $row['Password']; ?> </td>
                    <td> <?php echo $row['Email']; ?> </td>
                    <td> <?php echo $row['Role']; ?></td>
                    <td>
                    <a href="edit_user.php?id=<?php echo $id;?>">
                            Edit
                        </a>

                    </td>
                    <td>

                        <a href="delete_user.php?id=<?php echo $id;?>">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
            </tbody>

    <?php 
            }
    ?>
        </table>
    </div>
    </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>