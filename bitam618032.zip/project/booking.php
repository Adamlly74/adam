<?php include("connection.php");
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add booking</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
</head>
<body>
    <form action="save_booking.php" method="POST" name="addUser_Form">
    
        <div class="form-group row"> 
            <label for="inputName" class="col-sm-2 col-form-label">Start time:</label>
            <input type="text" class="form-control col-sm-4" name="stime" id="inputName" placeholder="Enter Start time"> 
        </div> 

        <div class="form-group row"> 
            <label for="inputUname" class="col-sm-2 col-form-label">Ending time:</label>
            <input type="text" class="form-control col-sm-4" name="etime" placeholder="Enter End time" id="inputUserName"> 
        </div> 

        <div class="form-group row"> 
            <label for="inputPassword" class="col-sm-2 col-form-label">Duration:</label>
            <input type="text" class="form-control col-sm-4" placeholder="Enter duration" name="duration" id="inputPassword"> 
        </div> 

      
        <button type="submit" name="submit" class="btn btn-primary">Update</button> 

</form>  
</body>
</html>