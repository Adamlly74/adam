<?php
    include("connection.php");


    if(isset($_POST['submit'])
        && isset($_POST['pname']) 
        && isset($_POST['ptype']) 
        && isset($_POST['pdesc'])){

            $sql="INSERT INTO parking (Parking_name,Parking_Type,Parking_Desc) 
            VALUES(:pname,:ptype,:pdesc)";
            $stmt=$con->prepare($sql);
            $stmt->execute(array(
                ':pname'=>$_POST['pname'],
                ':ptype'=>$_POST['ptype'],
                ':pdesc'=>$_POST['pdesc']));
            header("location:add_parking.php");
    }
?>