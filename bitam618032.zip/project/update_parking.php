<?php
    include("connection.php");

if(isset($_POST['submit'])){

    $sql="UPDATE parking SET Parking_Name=:name,Parking_Type=:uname,Parking_Desc=:pass
     WHERE Parking_ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(
        ':id'=>$_POST['id'],
        ':name'=>$_POST['name'],
        ':uname'=>$_POST['uname'],
        ':pass'=>$_POST['pass']));
    header("location:view_parking.php");
}
    
?>