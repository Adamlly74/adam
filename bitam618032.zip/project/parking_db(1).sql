-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2020 at 10:22 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `Booking_ID` int(11) NOT NULL,
  `Starting_time` varchar(50) DEFAULT NULL,
  `Ending_time` varchar(50) DEFAULT NULL,
  `Duration` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`Booking_ID`, `Starting_time`, `Ending_time`, `Duration`) VALUES
(2, '11:00', '7:00', '3hour');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `Owner_ID` int(11) NOT NULL,
  `FullName` varchar(255) DEFAULT NULL,
  `Phone_No` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE `parking` (
  `Parking_ID` int(11) NOT NULL,
  `Parking_Name` varchar(255) DEFAULT NULL,
  `Parking_Type` varchar(255) DEFAULT NULL,
  `Parking_Desc` varchar(255) DEFAULT NULL,
  `Booking_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parking`
--

INSERT INTO `parking` (`Parking_ID`, `Parking_Name`, `Parking_Type`, `Parking_Desc`, `Booking_ID`) VALUES
(1, 'Forodhani', 'Luxury', 'For foreigners only', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `ID` int(11) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`ID`, `FullName`, `UserName`, `Password`, `Email`, `Role`) VALUES
(6, 'Abullah Juma', 'abdullah', '12345', 'dulla@gmail.com', 'Owner'),
(9, 'Adam Hassan', 'adamjuma', '12345', 'adam@gmail.com', 'Admin'),
(10, 'AbdulHafidh', 'dully', '12345', 'dully@gmail.com', 'Owner');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `Vehicle_ID` int(11) NOT NULL,
  `Vehicle_Name` varchar(255) DEFAULT NULL,
  `Vehicle_Type` varchar(255) DEFAULT NULL,
  `ID` int(11) DEFAULT NULL,
  `Parking_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`Vehicle_ID`, `Vehicle_Name`, `Vehicle_Type`, `ID`, `Parking_ID`) VALUES
(1, 'rosepoice', 'Suzuki', NULL, NULL),
(2, 'Carry', NULL, NULL, NULL),
(3, 'Carry', NULL, NULL, NULL),
(4, '', 'Select your Vehicle', NULL, NULL),
(5, '', 'Select your Vehicle', NULL, NULL),
(6, '', 'Select your Vehicle', NULL, NULL),
(7, '', 'Select your Vehicle', NULL, NULL),
(8, 'carry', 'Suzuki', NULL, NULL),
(9, '', 'Select your Vehicle', NULL, NULL),
(10, '', 'Select your Vehicle', NULL, NULL),
(11, '', 'Select your Vehicle', NULL, NULL),
(12, '', 'Select your Vehicle', NULL, NULL),
(13, '', 'Select your Vehicle', NULL, NULL),
(14, '', 'Select your Vehicle', NULL, NULL),
(15, '', 'Select your Vehicle', NULL, NULL),
(16, '', 'Select your Vehicle', NULL, NULL),
(17, 'g', 'Select your Vehicle', NULL, NULL),
(18, '', 'Select your Vehicle', NULL, NULL),
(19, '', 'Select your Vehicle', NULL, NULL),
(20, 'carry', 'Rava J', NULL, NULL),
(21, 'Carry', 'Suzuki', NULL, NULL),
(22, '', 'Select your Vehicle', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`Booking_ID`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`Owner_ID`);

--
-- Indexes for table `parking`
--
ALTER TABLE `parking`
  ADD PRIMARY KEY (`Parking_ID`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`Vehicle_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `Booking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `owner`
--
ALTER TABLE `owner`
  MODIFY `Owner_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parking`
--
ALTER TABLE `parking`
  MODIFY `Parking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `Vehicle_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
