<!DOCTYPE html>
<html lang="en">
<head>
        <?php include("navs.php") ?>
</head>
<body>
    <div class="container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Vehicle Name</th>
                    <th>vehicle type</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
    <?php
            include_once("connection.php");
            $sql = "SELECT * FROM vehicle";
            $stmt=$con->query($sql);

            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $id=$row['ID'];
                $name=$row['Vehicle_Name'];
                $uname=$row['Vehicle_Type'];  
    ?>
            </thead>

            <tbody>
                <tr> 
                    <td> <?php echo $row['ID']; ?> </td>
                    <td> <?php echo $row['Vehicle_Name']; ?> </td>
                    <td> <?php echo $row['Vehicle_Type']; ?> </td>
                    <td>
                    <a href="edit_vehicle.php?id=<?php echo $id;?>">
                            Edit
                        </a>

                    </td>
                    <td>

                        <a href="delete_vehicle.php?id=<?php echo $id;?>">
                            Delete
                        </a>
                    </td>
                </tr>
            </tbody>

    <?php 
            }
    ?>
        </table>
    </div>
    </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>