<?php
    include("connection.php");

if(isset($_POST['submit'])
&& isset($_POST['id'])
&& isset($_POST['name']) 
&& isset($_POST['uname']) 
&& isset($_POST['pass']) 
&& isset($_POST['email'])
&& isset($_POST['role'])){

    $sql="UPDATE user_details SET FullName=:name,UserName=:uname,Password=:pass,
    Email=:email,Role=:role WHERE ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(
        ':name'=>$_POST['name'],
        ':uname'=>$_POST['uname'],
        ':pass'=>$_POST['pass'],
        ':email'=>$_POST['email'],
        ':role'=>$_POST['role']));
    //header("location:view_user.php");
}
    
?>