<?php
    include("connection.php");


    if(isset($_POST['submit']))
       {

            $sql="INSERT INTO vehicle (Vehicle_Name,Vehicle_Type) 
            VALUES(:v_name,:v_type)";
            $stmt=$con->prepare($sql);
            $stmt->execute(array(
                ':v_name'=>$_POST['v_name'],
                ':v_type'=>$_POST['v_type']));
            header("location:add_vehicle.php");
            echo "success";
    }else{
        echo "fail";
    }
?>