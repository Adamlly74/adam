
<?php
    session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <div class="container">
    <?php include("nav.php"); ?>
</div>
<style>
    body{
        background-color: #18454A;
        color: white;
    }
   
</style>
</head>
<body>
    <div class="jumbotron jumbotron-fluid" id="jumbroton-fluid">
        <div class="container">
          <h3>WELCOME TO PARKING SPACE</h3>
          <h6>MANAGEMENT SYSTEM</h6>
        </div>
    </div>

    <div class="container">
        <div class="row">
       
            <div class="col-md-4">
                <img src="img/img1.jpeg" class="img-thumbnail" alt="no image found" width="300px" height="200px" id="zoom">
                <p style="margin-top: 4%;">Some information here!!!!
                    Change management is the process, tools and techniques to manage the peoples
                    side of change so as to achieve the require organization outcomes or goals.
                    It’s in cooperate the organization tools can be utilized to helps individual
                    make successful personal transitions resulting in the adaptation and realization
                    of change when introduced to the organization, also when the change are introduced
                    can be impacting one or more of the following, process, system, organization structure
                    or job roles.
                </p>
            </div>
            <div class="col-md-4">
                <img src="img/img1.jpeg" class="img-thumbnail" alt="no image found" width="300px" height="200px" id="zoom">
                <p style="margin-top: 4%;">Some information here!!!!
                    Change management is the process, tools and techniques to manage the peoples
                    side of change so as to achieve the require organization outcomes or goals.
                    It’s in cooperate the organization tools can be utilized to helps individual
                    make successful personal transitions resulting in the adaptation and realization
                    of change when introduced to the organization, also when the change are introduced
                    can be impacting one or more of the following, process, system, organization structure
                    or job roles.  
                </p>
            </div>
            <div class="col-md-4">
                <img src="img/img1.jpeg" class="img-thumbnail"  alt="no image found" width="300px" height="200px" id="zoom">
                <p style="margin-top: 4%;">Some information here!!!!
                    Change management is the process, tools and techniques to manage the peoples
                    side of change so as to achieve the require organization outcomes or goals.
                    It’s in cooperate the organization tools can be utilized to helps individual
                    make successful personal transitions resulting in the adaptation and realization
                    of change when introduced to the organization, also when the change are introduced
                    can be impacting one or more of the following, process, system, organization structure
                    or job roles. 
                <?php    echo $_SESSION["role"]; ?>
                </p>
            </div>
        </div>

    </div>
    
    <div class="footer">
    <i class="fa fa-copyright"></i>
    Copy Right</div>
</body>
</html>