<?php
    include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <link rel="staylesheet" href="fontawesome-free-5.13.1-web/css/all.min.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="bootstrap-4.5.0-dist/css/bootstrap.min.css">
    <div class="container">
</head>
<body>
    <table border="1px">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Pasword</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>

        <?php
            $sql = "SELECT * FROM staff";
            $st=$con->query($sql);
           

            while($row=$st->fetch(PDO::FETCH_ASSOC)){
                $count = 1;
                $id=$row['Id'];
                $fname=$row['FullName'];
                $mail=$row['Email'];
                $pass=$row['Password'];
                
        
        ?>
        <tr>
            <td><?php echo $count++; ?></td>
            <td><?php echo $row['FullName']; ?></td>
            <td><?php echo $row['Email']; ?></td>
            <td><?php echo $row['Password']; ?></td>
            <td>
                <a href="edit_staff.php">
                    Edit
                </a>
            </td>
            <td> 
                <a href="delete_staff.php?id=$id">
                    Delete
                </a>
            </td>
        </tr>
        <?php
             }
             
        ?>
       
    </table>
</body>
</html>