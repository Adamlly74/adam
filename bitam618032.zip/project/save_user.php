<?php
    include("connection.php");


    if(isset($_POST['submit'])
        && isset($_POST['name']) 
        && isset($_POST['uname']) 
        && isset($_POST['pass']) 
        && isset($_POST['email'])
        && isset($_POST['role'])){

            $sql="INSERT INTO user_details (FullName,UserName,Password,Email,Role) 
            VALUES(:name,:uname,:pass,:email,:role)";
            $stmt=$con->prepare($sql);
            $stmt->execute(array(
                ':name'=>$_POST['name'],
                ':uname'=>$_POST['uname'],
                ':pass'=>$_POST['pass'],
                ':email'=>$_POST['email'],
                ':role'=>$_POST['role']));
            header("location:add_user.php");
    }
?>