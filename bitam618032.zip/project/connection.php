<?php 
    try{
        $con = new PDO("mysql:host=localhost;port=3306;dbname=parking_db",'root','');
        $con->SetAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e){
        echo "Connection fail:".$e->getMessage();
    }
    
?>