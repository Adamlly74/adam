<?php 
    include("connection.php");

    $sql = "DELETE FROM vehicle WHERE Vehicle_ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(':id'=>$_GET['id']));
   header("Location:view_vehicle.php");
?>