<!DOCTYPE html>
<html lang="en">
<head>
        <?php include("navs.php") ?>
</head>
<body>
    <div class="container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Start time</th>
                    <th>End time</th>
                    <th>Duration</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
    <?php
            include_once("connection.php");
            $sql = "SELECT * FROM booking";
            $stmt=$con->query($sql);

            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $id=$row['Booking_ID'];
                $name=$row['Starting_time'];
                $uname=$row['Ending_time'];
                $pass=$row['Duration'];
    
    ?>
            </thead>

            <tbody>
                <tr> 
                    <td> <?php echo $row['Booking_ID']; ?> </td>
                    <td> <?php echo $row['Starting_time']; ?> </td>
                    <td> <?php echo $row['Ending_time']; ?> </td>
                    <td> <?php echo $row['Duration']; ?> </td>
                    <td>
                    <a href="edit_booking.php?id=<?php echo $id;?>">
                            Edit
                        </a>

                    </td>
                    <td>

                        <a href="delete_booking.php?id=<?php echo $id;?>">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
            </tbody>

    <?php 
            }
    ?>
        </table>
    </div>
    </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>