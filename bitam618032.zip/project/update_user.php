<?php
    include("connection.php");

if(isset($_POST['submit'])){

    $sql="UPDATE user_details SET FullName=:name,UserName=:uname,Password=:pass,
    Email=:email,Role=:role WHERE ID=:id";
    $stmt=$con->prepare($sql);
    $stmt->execute(array(
        ':name'=>$_POST['name'],
        ':uname'=>$_POST['uname'],
        ':pass'=>$_POST['pass'],
        ':email'=>$_POST['email'],
        ':role'=>$_POST['role'],
        ':id'=>$_POST['id']
    ));
    header("location:view_user.php");
}else{
    echo "noo";
}
    
?>